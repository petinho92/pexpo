SET FOREIGN_KEY_CHECKS = 0;
--run down.table.*.sql
--run down.view.*.sql
SET FOREIGN_KEY_CHECKS = 1;
