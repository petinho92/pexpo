SET FOREIGN_KEY_CHECKS = 0;
--run up.table.*.sql
--run up.view.*.sql
SET FOREIGN_KEY_CHECKS = 1;
