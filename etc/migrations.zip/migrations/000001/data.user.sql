INSERT INTO `user` (`id`, `attachments`, `guid`, `created`, `updated`, `password`, `name`, `email`, `group`)
VALUES
(1, '{\"files\": [], \"collections\": []}', 'a34b8bd4-9eac-11eb-9a44-e85e1d75f468', '2021-04-16 12:09:47', '2021-05-27 10:53:24', '$2y$10$sP6xSpSDVkYVVFfGe6hOGu09IF/igp.cqLWygkCagM/RQb9tC/5Nu', 'Atomino', 'atomino@atomino.atom', 'admin');
